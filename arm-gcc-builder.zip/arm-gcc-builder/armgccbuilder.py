import struct
import os
import subprocess

target = 'HART-Multiplexer.bin'

path = 'D:/0/AT32IDE/platform/tools/Build Tools/bin;D:/0/AT32IDE/platform/tools/gcc-arm-none-eabi-10.3-2021.10/bin;'

def calculation_crc32(filename):
    if not os.path.exists(filename):
        return None
    with open(filename, 'rb') as fp:
        bin = fp.read()
    crc32 = 0xFFFFFFFF
    polynomial = 0x04C11DB7
    size = len(bin)
    for data in struct.unpack('i' * int(size / 4), bin):
        xbit = 1 << 31
        while xbit:
            if crc32 & 0x80000000:
                crc32 = (crc32 << 1) & 0xFFFFFFFF
                crc32 = (crc32 ^ polynomial) & 0xFFFFFFFF
            else:
                crc32 = (crc32 << 1) & 0xFFFFFFFF
            if data & xbit:
                crc32 = (crc32 ^ polynomial) & 0xFFFFFFFF
            xbit = (xbit >> 1) & 0xFFFFFFFF
    return '{:08X}'.format(crc32)


def command(cmdline):
    process = subprocess.Popen(cmdline, stdout=subprocess.PIPE)
    last_line_not_empty = False
    while process.poll() is None:
        line = process.stdout.readline().strip().decode('UTF-8')
        line_not_empty = len(line) > 0
        if line_not_empty or last_line_not_empty:
            print(line)
        last_line_not_empty = line_not_empty


if __name__ == '__main__':
    os.environ['PATH'] = path + os.environ['PATH']
    command('make -j6')
    crc32 = calculation_crc32(target)
    if crc32:
        os.rename(target, target.replace('.bin', f'-CRC-{crc32}.bin'))
    command('make clean')
