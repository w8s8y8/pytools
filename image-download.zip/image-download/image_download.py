import requests
from lxml import html

def get(url, index):
	print(url)
	r = requests.get(url)
	if r:
		with open(f"images/{index}.webp", "wb") as fp:
			fp.write(r.content)
		return r
	return None


if __name__ == '__main__':
	with open('urls.txt', 'r') as fp:
		urls = fp.readlines()

	h = html.fromstring(urls[0])

	for page in range(1, 1580 + 10):
		x = f'//*[@id="page{page}"]/div/img//@data-url'
		link = h.xpath(x)
		if len(link) == 1:
			url = 'https://nvme1.bunnyssd.com/' + link[0]
			get(url, str(page - 1).rjust(4, '0'))
